<?php $__env->startSection('error-title', 'NOT FOUND'); ?>
<?php $__env->startSection('error-message', 'Halaman yang anda cari tidak ditemukan'); ?>

<?php echo $__env->make('errors._layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\IZUNA\Documents\GitHub\website-himatif\resources\views/errors/404.blade.php ENDPATH**/ ?>