<footer class="pt-0 footer ">
    <div class="container mx-auto sm:px-4">
        <div class="flex flex-wrap justify-between py-5">
            <div class="lg:w-1/3 pr-4 pl-4">
                <div class="flex items-center mb-2">
                    <img src="<?php echo e(asset('img/logo.png')); ?>" alt="" width="70px" class="mr-1">
                    <h3 class="text-dec text-dec-warning-2 text-dec-tr text-white font-bold mb-0">
                        HIMATIF
                    </h3>
                </div>
                <h6 class="text-link font-weight-semibold mb-6">
                    Jalan. Kalimantan No. 37, Kampus
                    Tegalboto, Jember, Jawa Timur,
                    68121, Indonesia
                </h6>

                <h5 class="text-white font-bold mb-5">SOCIAL</h5>
                <div class="flex flex-wrap  gutters-xs mb-1">
                    <div class="col-auto"><img src="<?php echo e(asset('img/icons/instagram.svg')); ?>" alt=""></div>
                    <div class="relative flex-grow max-w-full flex-1 px-4">
                        <h6 class="text-white font-weight-semibold">
                            <a class="text-white" href="https://www.instagram.com/himatifunej/"
                                target="_blank">@himatifunej</a>
                        </h6>
                    </div>
                </div>
                <div class="flex flex-wrap  gutters-xs mb-1">
                    <div class="col-auto"><img src="<?php echo e(asset('img/icons/youtube.svg')); ?>" alt=""></div>
                    <div class="relative flex-grow max-w-full flex-1 px-4">
                        
                        <h6 class="text-white font-weight-semibold">
                            <a class="text-white" href="https://www.youtube.com/@himatifunej3573"
                                target="_blank">Himatif
                                Unej</a>
                        </h6>
                    </div>
                </div>
                <div class="flex flex-wrap  gutters-xs mb-1">
                    <div class="col-auto"><img src="<?php echo e(asset('img/icons/tiktok.svg')); ?>" alt=""></div>
                    <div class="relative flex-grow max-w-full flex-1 px-4">
                        
                        <h6 class="text-white font-weight-semibold">
                            <a class="text-white" href="https://www.tiktok.com/@himatifunej"
                                target="_blank">@himatifunej</a>
                        </h6>
                    </div>
                </div>
                <div class="flex flex-wrap  gutters-xs mb-1">
                    <div class="col-auto"><img src="<?php echo e(asset('img/icons/linkedin.svg')); ?>" alt=""></div>
                    <div class="relative flex-grow max-w-full flex-1 px-4">
                        
                        <h6 class="text-white font-weight-semibold">
                            <a class="text-white" href="https://www.linkedin.com/company/himatifunej"
                                target="_blank">Himatif Unej</a>
                        </h6>
                    </div>
                </div>
            </div>
            

            <div class="divider lg:hidden before:bg-white after:bg-white bg-transparent"></div>

            <div class="md:w-1/2 lg:w-1/4 pr-4 pl-4 lg:mx-1/6 py-4">
                <h5 class="text-white font-extrabold mb-2">NAVIGASI</h5>
                <ul class="flex flex-wrap list-none pl-0 mb-0 flex-col">
                    <li class="">
                        <a class="inline-block py-2 px-4 no-underline text-white font-weight-semibold pl-0 active"
                            href="<?php echo e(route('frontpage.homepage')); ?>">BERANDA</a>
                    </li>
                    <li class="">
                        <a class="inline-block py-2 px-4 no-underline text-white font-weight-semibold pl-0 active"
                            href="<?php echo e(route('frontpage.about')); ?>">TENTANG</a>
                    </li>
                    <li class="">
                        <a class="inline-block py-2 px-4 no-underline text-white font-weight-semibold pl-0 active"
                            href="<?php echo e(route('frontpage.pengurus')); ?>">DIVISI & PENGURUS</a>
                    </li>
                    <li class="">
                        <a class="inline-block py-2 px-4 no-underline  text-white font-weight-semibold pl-0"
                            href="<?php echo e(route('frontpage.proker')); ?>">PROKER</a>
                    </li>
                    <li class="">
                        <a class="inline-block py-2 px-4 no-underline  text-white font-weight-semibold pl-0"
                            href="<?php echo e(route('frontpage.berita')); ?>">BERITA</a>
                    </li>
                </ul>
            </div>
            

            <div class="divider lg:hidden before:bg-white after:bg-white bg-transparent"></div>

            <div class="md:w-1/2 pr-4 pl-4 lg:w-1/3 pr-4 pl-4 pt-2">
                <h5 class="text-white font-weight-extrabold mb-2">BERITA TERBARU</h5>

                
                <?php $__currentLoopData = \App\Models\Post::take(3)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex flex-wrap  gutters-sm items-center mb-1">
                        <div class="col-auto">
                            <div
                                class="relative flex flex-col min-w-0 rounded-md break-words border bg-white border-1 border-gray-300">
                                <div class="flex-auto p-6" style="padding: .5rem">
                                    <div class="img-fit img-fit-cover w-[3rem] h-[3rem]">
                                        <?php if($post->photo): ?>
                                            <img src="<?php echo e(asset('storage/' . $post->photo)); ?>" alt="">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('img/placeholder/product-image-default.svg')); ?>"
                                                alt="">
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="relative flex-grow max-w-full flex-1 px-4">
                            <a href="<?php echo e(route('frontpage.berita.show', $post->slug)); ?>"
                                class="text-14 text-link font-semibold">
                                <?php echo e(substr(strip_tags($post->title), 0, 20) . (strlen(strip_tags($post->title)) > 20 ? '...' : '')); ?>

                            </a>
                            <div class="text-sm font-light text-link op-7">
                                <?php echo e(substr(strip_tags($post->title), 0, 30) . (strlen(strip_tags($post->title)) > 30 ? '...' : '')); ?>

                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                
                <div class="flex items-center text-white font-weight-semibold mt-2">
                    <a href="<?php echo e(route('frontpage.berita')); ?>" class="text-white">
                        Lihat Semua Blog
                    </a>
                    <i class="fas fa-arrow-right text-height-0 ml-1"></i>
                </div>

            </div>
        </div>

        <div class="divider  before:bg-white after:bg-white bg-transparent"></div>
        <div class="text-link text-center font-bold">Copyright &copy; <?php echo e(date('Y')); ?>. Himatif, All rights
            reserved </div>
    </div>
</footer>
<?php /**PATH C:\Users\IZUNA\Documents\GitHub\website-himatif\resources\views/frontpage/layouts/footer.blade.php ENDPATH**/ ?>