<nav class="bg-[#f3f2eb] border-[#ffc107] border-b-2 relative z-40 px-8 py-4">
    <div class="navbar ">
        <div class="navbar-start">
            <div class="dropdown">
                <div id="dropdownToggle" tabindex="0" role="button" class="btn btn-ghost lg:hidden">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24"
                        stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M4 6h16M4 12h8m-8 6h16" />
                    </svg>
                </div>
                <ul id="dropdownMenu" class="dropdown-content mt-3 p-2 shadow bg-white rounded-box w-52 px-5">
                    <li class="text-sm max-lg:py-3">
                        <a class="relative w-fit block  after:block after:content-[''] after:absolute after:h-[3px] 
                            after:bg-[#ffc107] after:w-full after:scale-x-0 after:hover:scale-x-100 after:transition after:duration-300 after:origin-center 
                            <?php echo e(Request::is('/') ? 'after:scale-x-100' : ''); ?>"
                            href="<?php echo e(url('/')); ?>">BERANDA</a>

                    </li>
                    <li class="text-sm max-lg:py-3">
                        <a class="relative w-fit block after:block after:content-[''] after:absolute after:h-[3px] 
                            after:bg-[#ffc107] after:w-full after:scale-x-0 after:hover:scale-x-100 after:transition after:duration-300 after:origin-center 
                            <?php echo e(Request::is('tentang') ? 'after:scale-x-100' : ''); ?>"
                            href="<?php echo e(url('/tentang')); ?>">TENTANG</a>
                    </li>
                    <li class="text-sm max-lg:py-3 ">
                        <a class="relative w-fit block after:block after:content-[''] after:absolute after:h-[3px] 
                        after:bg-[#ffc107] after:w-full after:scale-x-0 after:hover:scale-x-100 after:transition after:duration-300 after:origin-center 
                        <?php echo e(Request::is('pengurus') ? 'after:scale-x-100' : ''); ?>"
                            href="<?php echo e(url('/pengurus')); ?>">DIVISI & PENGURUS</a>
                    </li>
                    <li class="text-sm max-lg:py-3">
                        <a class="relative w-fit block after:block after:content-[''] after:absolute after:h-[3px] 
                        after:bg-[#ffc107] after:w-full after:scale-x-0 after:hover:scale-x-100 after:transition after:duration-300 after:origin-center 
                        <?php echo e(Request::is('proker*') ? 'after:scale-x-100' : ''); ?>"
                            href="<?php echo e(url('/proker')); ?>">PROKER</a>
                    </li>
                    <li class="text-sm max-lg:py-3">
                        <a class="relative w-fit block after:block after:content-[''] after:absolute after:h-[3px] 
                        after:bg-[#ffc107] after:w-full after:scale-x-0 after:hover:scale-x-100 after:transition after:duration-300 after:origin-center 
                        <?php echo e(Request::is('berita*') ? 'after:scale-x-100' : ''); ?>"
                            href="<?php echo e(url('/berita')); ?>">BERITA</a>
                    </li>
                    <li class="text-sm max-lg:py-3 group ">
                        <a
                            class="z-30 text-black cursor-pointer relative w-fit block after:block after:content-[''] after:absolute after:h-[3px] 
                            after:bg-[#ffc107] after:w-full after:scale-x-0 after:hover:scale-x-100 after:transition after:duration-300 after:origin-center 
                            <?php echo e(Request::is('nim-checker') || Request::is('CakapxHimatif') ? 'after:scale-x-100' : ''); ?>">
                            LAINNYA
                        </a>
                        <ul class="p-2 ">
                            <li><a class="py-3 mx-2 text-black cursor-pointer relative w-fit block after:block after:content-[''] after:absolute after:h-[3px] 
                                    after:bg-[#ffc107] after:w-full after:scale-x-0 after:hover:scale-x-100 after:transition after:duration-300 after:origin-center 
                                    <?php echo e(Request::is('nim-checker') ? 'after:scale-x-100' : ''); ?>"
                                    href="<?php echo e(url('/nim-checker')); ?>">
                                    NIM CHECKER
                                </a>
                            </li>
                            <li><a class="py-3 mx-2 text-black cursor-pointer relative w-fit block after:block after:content-[''] after:absolute after:h-[3px] 
                                after:bg-[#ffc107] after:w-full after:scale-x-0 after:hover:scale-x-100 after:transition after:duration-300 after:origin-center 
                                <?php echo e(Request::is('CakapxHimatif') ? 'after:scale-x-100' : ''); ?>"
                                    href="<?php echo e(url('/CakapxHimatif')); ?>">
                                    CAKAPxHIMATIF
                                </a>
                            </li>
                            <li><a class="py-3 mx-2 text-black cursor-pointer relative w-fit block after:block after:content-[''] after:absolute after:h-[3px] 
                                after:bg-[#ffc107] after:w-full after:scale-x-0 after:hover:scale-x-100 after:transition after:duration-300 after:origin-center 
                                <?php echo e(Request::is('pemilu*') ? 'after:scale-x-100' : ''); ?>"
                                    href="<?php echo e(url('/pemilu')); ?>">
                                    PEMILU
                                </a>
                            </li>
                        </ul>

                    </li>

                </ul>
                <script>
                    const dropdownToggle = document.getElementById("dropdownToggle");
                    const dropdownMenu = document.getElementById("dropdownMenu");

                    dropdownToggle.addEventListener("click", function(event) {
                        event.stopPropagation();
                        dropdownMenu.classList.toggle("show");
                    });

                    document.addEventListener("click", function(event) {
                        if (!dropdownMenu.contains(event.target) && !dropdownToggle.contains(event.target)) {
                            dropdownMenu.classList.remove("show");
                        }
                    });
                </script>
                <style>
                    .dropdown-content {
                        display: none;
                    }

                    .dropdown-content.show {
                        display: block;
                    }
                </style>
            </div>
            <a class="flex items-center space-x-2 rtl:space-x-reverse" href="<?php echo e(route('frontpage.homepage')); ?>">
                <img src="<?php echo e(asset('img/logo.png')); ?>" class="navbar-brand-image h-8" alt="Logo Himatif">
                <div class="self-center text-xl font-semibold whitespace-nowrap ">HIMATIF</div>
            </a>
        </div>
        <div class="navbar-center hidden bg-transparent lg:flex">
            <ul
                class="flex flex-col font-medium p-6 md:p-0 mt-4 border border-gray-100 rounded-lg md:space-x-8 rtl:space-x-reverse md:flex-row md:mt-0 md:border-0  ">
                <li class="text-sm max-md:py-3">
                    <a class="relative w-fit block after:block after:content-[''] after:absolute after:h-[3px] 
                            after:bg-[#ffc107] after:w-full after:scale-x-0 after:hover:scale-x-100 after:transition after:duration-300 after:origin-center 
                            <?php echo e(Request::is('/') ? 'after:scale-x-100' : ''); ?>"
                        href="<?php echo e(url('/')); ?>">BERANDA</a>

                </li>
                <li class="text-sm max-md:py-3">
                    <a class="relative w-fit block after:block after:content-[''] after:absolute after:h-[3px] 
                            after:bg-[#ffc107] after:w-full after:scale-x-0 after:hover:scale-x-100 after:transition after:duration-300 after:origin-center 
                            <?php echo e(Request::is('tentang') ? 'after:scale-x-100' : ''); ?>"
                        href="<?php echo e(url('/tentang')); ?>">TENTANG</a>
                </li>
                <li class="text-sm max-md:py-3 ">
                    <a class="relative w-fit block after:block after:content-[''] after:absolute after:h-[3px] 
                        after:bg-[#ffc107] after:w-full after:scale-x-0 after:hover:scale-x-100 after:transition after:duration-300 after:origin-center 
                        <?php echo e(Request::is('pengurus') ? 'after:scale-x-100' : ''); ?>"
                        href="<?php echo e(url('/pengurus')); ?>">DIVISI & PENGURUS</a>
                </li>
                <li class="text-sm max-md:py-3">
                    <a class="relative w-fit block after:block after:content-[''] after:absolute after:h-[3px] 
                        after:bg-[#ffc107] after:w-full after:scale-x-0 after:hover:scale-x-100 after:transition after:duration-300 after:origin-center 
                        <?php echo e(Request::is('proker*') ? 'after:scale-x-100' : ''); ?>"
                        href="<?php echo e(url('/proker')); ?>">PROKER</a>
                </li>
                <li class="text-sm max-md:py-3">
                    <a class="relative w-fit block after:block after:content-[''] after:absolute after:h-[3px] 
                        after:bg-[#ffc107] after:w-full after:scale-x-0 after:hover:scale-x-100 after:transition after:duration-300 after:origin-center 
                        <?php echo e(Request::is('berita*') ? 'after:scale-x-100' : ''); ?>"
                        href="<?php echo e(url('/berita')); ?>">BERITA</a>
                </li>
                <li class="text-sm max-md:py-3 group ">
                    <a
                        class="z-30 text-black cursor-pointer relative w-fit block after:block after:content-[''] after:absolute after:h-[3px] 
                        after:bg-[#ffc107] after:w-full after:scale-x-0 after:hover:scale-x-100 after:transition after:duration-300 after:origin-center 
                        <?php echo e(Request::is('nim-checker') || Request::is('CakapxHimatif') ? 'after:scale-x-100' : ''); ?>">
                        LAINNYA
                    </a>

                    <ul class="hidden group-hover:block absolute  -ml-24 ">
                        <div class="h-2"></div>
                        <div class="bg-white rounded-lg z-20 shadow-md py-2 px-4 flex flex-col gap-2">
                            <li>
                                <a class="pt-2 w-32 text-center text-black cursor-pointer relative  block after:block after:content-[''] after:absolute after:h-[3px] 
                                    after:bg-[#ffc107] after:w-full after:scale-x-0 after:hover:scale-x-100 after:transition after:duration-300 after:origin-center 
                                    <?php echo e(Request::is('nim-checker') ? 'after:scale-x-100' : ''); ?>"
                                    href="<?php echo e(url('/nim-checker')); ?>">
                                    NIM CHECKER
                                </a>
                            </li>
                            <li>
                                <a class="py-2 w-32 text-center text-black cursor-pointer relative block after:block after:content-[''] after:absolute after:h-[3px] 
                                after:bg-[#ffc107] after:w-full after:scale-x-0 after:hover:scale-x-100 after:transition after:duration-300 after:origin-center 
                                <?php echo e(Request::is('CakapxHimatif') ? 'after:scale-x-100' : ''); ?>"
                                    href="<?php echo e(url('/CakapxHimatif')); ?>">
                                    CAKAPxHIMATIF
                                </a>
                            </li>
                            <li>
                                <a class="py-2 w-32 text-center text-black cursor-pointer relative block after:block after:content-[''] after:absolute after:h-[3px] 
                                after:bg-[#ffc107] after:w-full after:scale-x-0 after:hover:scale-x-100 after:transition after:duration-300 after:origin-center 
                                <?php echo e(Request::is('pemilu*') ? 'after:scale-x-100' : ''); ?>"
                                    href="<?php echo e(url('/pemilu')); ?>">
                                    PEMILU
                                </a>
                            </li>
                        </div>


                    </ul>

                </li>
            </ul>
        </div>

    </div>
    
</nav>
<?php /**PATH C:\Users\IZUNA\Documents\GitHub\website-himatif\resources\views/frontpage/layouts/navbar.blade.php ENDPATH**/ ?>