<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>HIMATIF | <?php echo $__env->yieldContent('title'); ?></title>

    <link rel="icon" type="image/png" href="<?php echo e(asset('img/favicon-32x32.png')); ?>" sizes="32x32" />
    <link rel="icon" type="image/png" href="<?php echo e(asset('img/favicon-16x16.png')); ?>" sizes="16x16" />

    

    
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app-frontpage.css']); ?>
    <?php echo $__env->yieldContent('style'); ?>
</head>

<body class="<?php echo $__env->yieldContent('pageClass'); ?> text-black">

    <?php echo $__env->make('frontpage.layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('frontpage.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('script'); ?>
</body>

</html>
<?php /**PATH C:\Users\IZUNA\Documents\GitHub\website-himatif\resources\views/frontpage/layouts/app-frontpage.blade.php ENDPATH**/ ?>